City of stairs — derived map data

© OpenStreetMap contributors. Local snapshot: 25 October 2026.
Database licence: Open Data Commons Open Database License 1.0.
https://opendatacommons.org/licenses/odbl/1-0/
https://www.openstreetmap.org/copyright

All GeoJSON coordinates are longitude and latitude in WGS 84.
overview.geojson: selected source stairway line records for the mainland overview.
overview-groups.geojson: display group positions, record counts and member identifiers.
detail.geojson: source pedestrian lines in the one-kilometre central detail.
timed-study.geojson: source pedestrian lines in the original four-kilometre study.
context.geojson: derived mainland surface and coastline used for context.
method.json: projection, grouping and symbol parameters, and original timed duration.

Grouping changes visible density. Source records are not counts of separate staircases.
Short step symbols in the map are enlarged. GeoJSON retains source geometry,
not enlarged graphic symbols. Access and completeness are not verified.
The artwork licence is separate from this database licence.
