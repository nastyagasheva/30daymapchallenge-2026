Vladivostok, Noon — derived geographic data

© OpenStreetMap contributors. Local snapshot: 25 October 2026.
Database licence: Open Data Commons Open Database License 1.0.
https://www.openstreetmap.org/copyright
https://opendatacommons.org/licenses/odbl/1-0/

All GeoJSON coordinates use WGS 84 longitude and latitude.
buildings.geojson, roads.geojson, paths.geojson, greenery.geojson:
selected recorded geometry clipped to the map window, with source identifiers.
land.geojson: derived coast-clipped land context, not administrative boundaries.
scenario.geojson: proposed places and three proposed partial shared uses within
recorded campus footprints. Fiction is explicitly tagged; it is not an inventory
of operating shared programmes, guest rooms or construction sites.
method.json: display parameters, scope and limits.
cooperation.json: imagined reciprocal relationships, not vessel tracks or
verified institutional partnerships. No travel times or access rights inferred.

Mapping completeness is not established. Green polygons are not a habitat
survey. The summer artists-village point on Reyneke is recorded source mapping;
its current operation is unverified. The historical Reyneke research base is
unlocated and is not included as a current or proposed base.
The Starka proposal is at neighbourhood scale, not a coordinate for its museum
or research station. Raw Copernicus terrain data are not included.
The cartographic artwork licence is separate from this database licence.
