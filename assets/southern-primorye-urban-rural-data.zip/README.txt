DAY 09 / CITIES AND FIELDS OF SOUTHERN PRIMORYE
Cartographic design: NG Cartography.
Artwork: Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International.
https://creativecommons.org/licenses/by-nc-sa/4.0/

This archive is an aggregate. Its files retain separate source terms:

region_outline.geojson: retained project geometry of OpenStreetMap relation 151225.
Copyright OpenStreetMap contributors. Open Database License 1.0.
The complete retained outline is included; the drawing uses only its southern frame.
https://www.openstreetmap.org/relation/151225
https://www.openstreetmap.org/copyright
https://opendatacommons.org/licenses/odbl/1-0/

settlement_locations.geojson: eight locations selected from the Center for Advanced
Governance (CPUR) Settlements of Russia dataset, release 12 March 2021.
Its general reference period is 2020, with some source records from earlier periods.
No population figures are included. CC BY-NC-SA 4.0.
https://data.rcsi.science/data-catalog/datasets/160/

worldcover_windows.json: window bounds, saved sample counts, map labels and method.
Land-cover source: ESA WorldCover 2021 v200, CC BY 4.0.
Copyright ESA WorldCover project 2021 / Contains modified Copernicus Sentinel
data (2021) processed by ESA WorldCover consortium.
Zanaga et al. (2022), ESA WorldCover 10 m 2021 v200.
https://doi.org/10.5281/zenodo.7254221
https://esa-worldcover.org/en/data-access
https://creativecommons.org/licenses/by/4.0/

Offshore water context: Natural Earth 1:10 million physical land, public domain.
https://www.naturalearthdata.com/about/terms-of-use/

No raw global raster tiles, reference images, population values or font software
are redistributed. The SVG has embedded map rasters, vector clipping, point and
legend marks, and outlined lettering. Lettering is not editable as ordinary text.
