DAY 11 / VLADIVOSTOK, IN FIVE BIRD VOICES

Artwork: NG Cartography, Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International.
https://creativecommons.org/licenses/by-nc-sa/4.0/

recordings.json: source observation URLs, attribution, dates, original file
hashes, reported coordinates and accuracy, and selected four-second intervals.
Species identifications belong to the iNaturalist community. Coordinates are
reported positions, not a claim of sub-metre accuracy.

spectra.npz: audio-derived spectra; keys f1..f5 are frequency in Hz,
t1..t5 are seconds from the first selected spectrogram frame, z1..z5 are
relative spectral power in logarithmic units. Arrays correspond to labels
01..05 in recordings.json. Creative Commons Attribution-NonCommercial;
retain the individual source credits and links in recordings.json.
Original audio files are not redistributed. Open the linked observations
to listen to the original recordings. Background is included.

coastline.geojson: copyright OpenStreetMap contributors, snapshot 25 October
2026, clipped working selection; WGS 84 longitude/latitude.
Open Database License 1.0:
https://www.openstreetmap.org/copyright
https://opendatacommons.org/licenses/odbl/1-0/

method.json: processing and drawing parameters, CC BY-NC-SA 4.0.
This is an aggregate with separate source licences, not one relicensed dataset.
No original audio files, font software or reference images are included.
The SVG has vector geometry and outlined lettering; text is not editable as text.
