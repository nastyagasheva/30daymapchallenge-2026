DAY 10 / LAND BETWEEN THE LINES
Artwork: NG Cartography, Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International.
https://creativecommons.org/licenses/by-nc-sa/4.0/

coastline.geojson and shore_gaps.geojson: derived from the existing OpenStreetMap
snapshot dated 25 October 2026. Copyright OpenStreetMap contributors.
Open Database License 1.0. Geographic coordinates are WGS84 longitude, latitude.
https://www.openstreetmap.org/copyright
https://opendatacommons.org/licenses/odbl/1-0/
The coastline is a clipped working selection, not a current legal-boundary survey.

method.json: retained drawing parameters and rounded selected profile maxima.
Height source: Copernicus GLO-30 Public, release 2021; original acquisition dates vary.
Produced using Copernicus WorldDEM-30. Copyright: DLR e.V. (2010-2014) and
Airbus Defence and Space GmbH (2014-2018). Data provided under Copernicus by the
European Union and the European Space Agency; all rights reserved.
https://registry.opendata.aws/copernicus-dem/
https://doi.org/10.5270/ESA-c5d3d65

This is an aggregate with separate source terms. No raw terrain tiles, font
software or reference images are redistributed. PNG is the accepted artwork;
SVG contains vector strokes and outlined lettering, not ordinary editable text.
Curved distance leaders are annotations; the short spans between shores carry
the measurements. Profile maxima are not summit heights. No sound or sea-depth
measurements, routes or access conditions are represented.
